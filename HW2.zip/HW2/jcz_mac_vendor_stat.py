import plotly.express as px
from mac_vendor_lookup import MacLookup
import os
import pandas as pd

path = "./lan"
files = os.listdir(path)

mac_set = set()
vendors_dict = {}

for file_name in files:
    print(file_name)

    f_ad = open(path + "/" + file_name, "r", encoding='windows-1252')

    f_lines = f_ad.read().splitlines()
    # print(f_lines)
    f_ad.close()

    timestamp = f_lines[0]
    ipRange = f_lines[1]
    mac_ip = []

    for i in range(2, len(f_lines)):
        mac_ip.append(f_lines[i])

    macsplit = []

    for dataline in mac_ip:
        macsplit.append(dataline.split())

    for data_tuple in macsplit:
        mac_set.add(data_tuple[0])

print("MACs registradas: ", len(mac_set))

# load vendors database
macad = MacLookup()
macad.load_vendors()

for mac_address in mac_set:
    try:
        # identify mac vendor
        mac_vendor = macad.lookup(mac_address)
        # add vendor to dictionary // update vendor frequency
        if mac_vendor in vendors_dict:
            vendors_dict[mac_vendor] = vendors_dict[mac_vendor] + 1
        else:
            vendors_dict[mac_vendor] = 1
    except KeyError:
        print("NO existe: ", mac_address)


print(vendors_dict)

vendors = []
freq = []
for k,v in vendors_dict.items():
    vendors.append(k)
    freq.append(v)


wide_df = pd.DataFrame(dict(Vendor=vendors, Dispositivos=freq))
tidy_df = wide_df.melt(id_vars="Vendor")
# print dataframe for plot
print(tidy_df)


mac_bar = px.bar(tidy_df, x="Vendor", y="value", color='variable')
mac_pie = px.pie(tidy_df, values="value", names="Vendor")
mac_bar.show()
mac_pie.show()
